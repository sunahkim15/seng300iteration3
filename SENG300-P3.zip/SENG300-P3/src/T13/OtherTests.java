package T13;

import java.util.Scanner; // import for top level type
import java.util.Map; // import for top level type

public class OtherTests { // normal type
	
	private Scanner s; // imported top level type
	private String str; // simple type
	private int[] arr = new int[5]; // primitive type and array
	private Map<String,Integer[]> map; // parameterized type (top-level)
	private OtherTests o; 
	
	public OtherTests() { // constructor for normal type
		
	}

}

public interface I {}

public enum E {}

public @interface A {}
