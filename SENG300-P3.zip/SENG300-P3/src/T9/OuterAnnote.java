package T9;
 
public @interface OuterAnnote {
	class InnerClass {}
	interface InnerInterface {}
	enum InnerEnum {}
	@interface InnerAnnote {}
}
