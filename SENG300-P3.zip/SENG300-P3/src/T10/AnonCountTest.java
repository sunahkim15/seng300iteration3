package T10;

// modified from https://docs.oracle.com/javase/tutorial/java/javaOO/anonymousclasses.html

public class AnonCountTest {
		  
	    interface HelloWorld {
	    }
        
        HelloWorld frenchGreeting = new HelloWorld() { // anon type declaration
        };
        
        public void m() {
            HelloWorld spanishGreeting = new HelloWorld() { // anon type declaration (within method)
            };
        }
        
}
