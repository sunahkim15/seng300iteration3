package T11;

public class NestedLocalDecTest {
	public void m() {
		class Local {
			class NestedLocal {}
		}
		
	}
}
