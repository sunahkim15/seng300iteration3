public class A {
        
        A Anon = new AnonClass() {}; 

}