package T12;

public class LocalTests {
	public void m() {
		class Local1{
			void m2() {
				class Local2{
					Local2 ref3;
				}
				Local2 ref4;
			}
			Local1 ref1;
		}
		Local1 ref2;
	}

}
