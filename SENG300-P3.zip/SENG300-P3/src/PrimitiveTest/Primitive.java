class Primitive {
    int a = 3; 
    char b = 1; 
    Integer c = 6;
}