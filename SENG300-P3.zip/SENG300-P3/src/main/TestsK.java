package main;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class TestsK {
	
	// BASE DIRECTORY
	String BASEDIR = "D:\\Aaron\\Desktop\\Eclipse\\SENG300-P3\\src";
	
	@Test
	public void test_anon() {
	    String path = BASEDIR + "\\AnonClassTest";   // subDirectory: directory with specific file to test
	    Main main = new Main(path);
	    
	    File dir = new File(path);
	    
	    List<File> javaFiles = new ArrayList<File>();
		
	    main.searchFiles(dir, javaFiles);
	    String source;
	    try {
	    	File f = javaFiles.get(0);
	    	source = main.readFile(f);
	    	
	    	Map<String, Integer[]> localMap = main.visit(main.parse(source,  f.getParent()));
	    	int	refCountA = localMap.get("A")[0];
	    	int	decCountA = localMap.get("A")[1];
	    	
	    	int refCountAnon = localMap.get("AnonClass")[0];
	    	int decCountAnon = localMap.get("AnonClass")[1];
	    	
	    	int refCountKey = localMap.get("LA$47; (Anonymous Class)")[0]; // Key may change for different devices
	    	int decCountKey = localMap.get("LA$47; (Anonymous Class)")[1];
	    	    	
	    	
	    	assertEquals(refCountA, 1);
	    	assertEquals(decCountA, 1);
	    	assertEquals(refCountAnon, 1);
	    	assertEquals(decCountAnon, 0);
	    	assertEquals(refCountKey, 0);
	    	assertEquals(decCountKey, 1);
	    }
	    catch (FileNotFoundException e) {
	    	e.printStackTrace();
	    }
	}
	
	@Test
	public void test_jar() {
	    String path = BASEDIR + "\\jarTest";   // subDirectory: directory with specific file to test
	    Main main = new Main(path);
	    
	    File dir = new File(path);
	    
	    List<File> javaFiles = new ArrayList<File>();
	    
		try {
			JarHandler.extractJars(dir);
		} catch (IOException e1) {
			e1.printStackTrace();
		}	
		
	    main.searchFiles(dir, javaFiles);
	    String source;
		    try {
		    	File f = javaFiles.get(0);
		    	source = main.readFile(f);
		    	
		    	Map<String, Integer[]> localMap = main.visit(main.parse(source,  f.getParent()));
	
		    	int refCount = localMap.get("Foo.Bar")[0];
		    	int decCount = localMap.get("Foo.Bar")[1];
	
		    	assertEquals(refCount, 2);
		    	assertEquals(decCount, 1);
		    }
		    catch (FileNotFoundException e) {
		    	e.printStackTrace();
		    }
	}
	
	@Test
	public void test_prim() {
	    String path = BASEDIR + "\\PrimitiveTest";   // subDirectory: directory with specific file to test
	    Main main = new Main(path);
	    
	    File dir = new File(path);
	    
	    List<File> javaFiles = new ArrayList<File>();
		
	    main.searchFiles(dir, javaFiles);
	    String source;
	    for (int i = 0; i < javaFiles.size(); i++) {
		    try {
		    	File f = javaFiles.get(0);
		    	source = main.readFile(f);
		    	
		    	Map<String, Integer[]> localMap = main.visit(main.parse(source,  f.getParent()));
	
		    	int	refCountInt = localMap.get("int")[0];
		    	int	decCountInt = localMap.get("int")[1];
		    	
		    	int refCountChar = localMap.get("char")[0];
		    	int decCountChar = localMap.get("char")[1];
		    	
		    	int refCountInteger = localMap.get("java.lang.Integer")[0];
		    	int decCountInteger = localMap.get("java.lang.Integer")[1];
		    	    	
		    	
		    	assertEquals(refCountInt, 1);
		    	assertEquals(decCountInt, 0);
		    	assertEquals(refCountChar, 1);
		    	assertEquals(decCountChar, 0);
		    	assertEquals(refCountInteger, 1);
		    	assertEquals(decCountInteger, 0);
		    }
		    catch (FileNotFoundException e) {
		    	e.printStackTrace();
		    }
	    }
	}
}