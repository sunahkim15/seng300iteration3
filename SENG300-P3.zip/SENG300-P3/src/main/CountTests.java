package main;

import static org.junit.Assert.*;

import org.junit.Test;

public class CountTests {

	String BASEDIR = "D:\\Aaron\\Desktop\\Eclipse\\SENG300-P3\\src";
	
	// test that anonymous type declarations are counted properly (independent of scope)
	@Test
	public void AnonCountTest() {
		String path = BASEDIR + "\\T10"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(2, Main.debug_anonDecCount);
	}
	
	// test that nested type declarations are counted properly (within class)
	@Test
	public void NestedCountTest1() {
		String path = BASEDIR + "\\T6"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(4, Main.debug_nestedDecCount);
	}
	
	// test that nested type declarations are counted properly (within interface)
	@Test
	public void NestedCountTest2() {
		String path = BASEDIR + "\\T7"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(4, Main.debug_nestedDecCount);
	}
	
	// test that nested type declarations are counted properly (within enum)
	@Test
	public void NestedCountTest3() {
		String path = BASEDIR + "\\T8"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(4, Main.debug_nestedDecCount);
	}	
	
	// test that nested type declarations are counted properly (within annotation)
	@Test
	public void NestedCountTest4() {
		String path = BASEDIR + "\\T9"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(4, Main.debug_nestedDecCount);
	}	
	
	// test that a type nested within a local class counts towards the NESTED count
	@Test
	public void NestedLocalDecTest() {
		String path = BASEDIR + "\\T11"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(1, Main.debug_nestedDecCount);
	}
	
	// test that local class declarations behave accordingly (simple case and a local within a local's method)
	@Test
	public void LocalTest1() {
		String path = BASEDIR + "\\T12"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(2, Main.debug_localDecCount);
	}	
	
	// test that local class references behave accordingly (at various scopes)
	@Test
	public void LocalTest2() {
		String path = BASEDIR + "\\T12"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(4, Main.debug_localRefCount);
	}		
	
	// test that no ANON/LOCAL/NESTED type declarations or references appear when we expect them not to for multiple scenarios
	@Test
	public void OtherTests() {
		String path = BASEDIR + "\\T13"; 
		String[] args = {path};
		Main.main(args); // run program
		assertEquals(0,Main.debug_anonDecCount);
		assertEquals(0,Main.debug_anonRefCount);
		assertEquals(0,Main.debug_localDecCount);
		assertEquals(0,Main.debug_localRefCount);
		assertEquals(0,Main.debug_nestedDecCount);
		assertEquals(0,Main.debug_nestedRefCount); 
	}	
	
	
}
