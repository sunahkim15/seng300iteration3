package T2;

public class LocalClassTest1 {
	
	public void m() {
		class Local {}
	}

}
